// JavaScript code can be added here for additional functionality
