package org.example.hoteldemo.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.antlr.v4.runtime.misc.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReservationDto {
    @NotNull
    private GuestDto guest;

    @NotNull
    private RoomDto room;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private String checkInDate;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private String checkOutDate;
}


