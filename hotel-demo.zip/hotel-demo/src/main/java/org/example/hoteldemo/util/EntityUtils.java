package org.example.hoteldemo.util;

import lombok.RequiredArgsConstructor;
import org.example.hoteldemo.dao.GuestDao;
import org.example.hoteldemo.dao.ReservationDao;
import org.example.hoteldemo.dao.RoomDao;
import org.example.hoteldemo.dto.GuestDto;
import org.example.hoteldemo.dto.ReservationDto;
import org.example.hoteldemo.dto.RoomDto;
import org.example.hoteldemo.entity.Guest;
import org.example.hoteldemo.entity.Reservation;
import org.example.hoteldemo.entity.Room;
import org.springframework.beans.BeanUtils;

import java.util.List;
import java.util.stream.Collectors;

@RequiredArgsConstructor
public class EntityUtils {

    private final RoomDao roomDao;
    private final GuestDao guestDao;
    private final ReservationDao reservationDao;

//    private final GuestDto guestDto;
//    private final RoomDto roomDto;
//    private final ReservationDto reservationDto;

    public GuestDto toGuestDto(Guest guest) {
        GuestDto guestDto = new GuestDto();
        BeanUtils.copyProperties(guest, guestDto);
        return guestDto;
    }

    public List<GuestDto> toGuestDtoList(List<Guest> guests) {
        return guests.stream().map(this::toGuestDto).collect(Collectors.toList());
    }

    public RoomDto toRoomDto(Room room) {
        RoomDto roomDto = new RoomDto();
        BeanUtils.copyProperties(room, roomDto);
        return roomDto;
    }

    public List<RoomDto> toRoomDtoList(List<Room> rooms) {
        return rooms.stream().map(this::toRoomDto).collect(Collectors.toList());
    }

    public ReservationDto toReservationDto(Reservation reservation) {
        ReservationDto reservationDto = new ReservationDto();
        BeanUtils.copyProperties(reservation, reservationDto);
        return reservationDto;
    }

    public List<ReservationDto> toReservationDtoList(List<Reservation> reservations) {
        return reservations.stream().map(this::toReservationDto).collect(Collectors.toList());
    }
}
