package org.example.hoteldemo.controller;

import lombok.RequiredArgsConstructor;
import org.example.hoteldemo.dto.ReservationDto;
import org.example.hoteldemo.entity.Guest;
import org.example.hoteldemo.service.GuestService;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequiredArgsConstructor
@RequestMapping("/api")
public class ReservationController {

    private final GuestService guestService;


    @GetMapping("/reservation-form")
    public String reservationForm(Model model) {
        model.addAttribute("reservation", new ReservationDto());
        return "reservation-form"; // Thymeleaf template
    }


    @PostMapping("/reservation")
    public ResponseEntity<String> createReservationWithNewGuest(@RequestBody ReservationDto reservationDto) {

        Guest guest = new Guest();
        guest.setName(reservationDto.getGuest().getName());
        guest.setPhone(reservationDto.getGuest().getPhone());
        guest.setGender(reservationDto.getGuest().getGender().getGender());


        String result = guestService.makeReservationWithNewGuest(
                guest,
                reservationDto.getRoom().getId(),
                reservationDto.getCheckInDate(),
                reservationDto.getCheckOutDate()
        );

        return ResponseEntity.ok(result);
    }
}
