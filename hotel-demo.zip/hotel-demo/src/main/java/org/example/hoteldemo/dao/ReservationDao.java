package org.example.hoteldemo.dao;

import org.example.hoteldemo.entity.Reservation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReservationDao extends JpaRepository<Reservation, Integer> {
}
