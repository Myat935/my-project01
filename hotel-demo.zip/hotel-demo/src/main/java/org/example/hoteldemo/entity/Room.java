package org.example.hoteldemo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Room {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private double price;


    @Enumerated(EnumType.STRING)
    private RoomType type;


    public enum RoomType {
        SINGLE, DOUBLE, SUITE
    }


    public Room(double price, RoomType type) {
        this.price = price;
        this.type = type;
    }

    @ManyToOne
    private Guest guest;

    @OneToMany(mappedBy = "room")
    private List<Reservation> reservations = new ArrayList<>();

    public void addReservation(Reservation reservation) {
        reservations.add(reservation);
        reservation.setRoom(this);
    }
}
