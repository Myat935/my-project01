package org.example.hoteldemo.dao;

import org.example.hoteldemo.entity.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;

public interface RoomDao extends JpaRepository<Room, Integer> {

    
    @Query("SELECT CASE WHEN COUNT(res) > 0 THEN false ELSE true END " +
            "FROM Reservation res WHERE res.room.id = :roomId " +
            "AND (res.checkInDate < :checkOutDate AND res.checkOutDate > :checkInDate)")
    boolean isRoomAvailable(@Param("roomId") int roomId,
                            @Param("checkInDate") String checkInDate,
                            @Param("checkOutDate") String checkOutDate);
}
