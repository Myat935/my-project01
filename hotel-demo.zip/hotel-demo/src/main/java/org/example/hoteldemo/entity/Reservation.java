package org.example.hoteldemo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.web.service.annotation.GetExchange;

import java.time.LocalDateTime;
@Entity
@Getter
@Setter
@NoArgsConstructor
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String checkInDate;
    private String checkOutDate;

    public Reservation( String checkInDate, String checkOutDate) {

        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }
    @ManyToOne
    private Room room;

    @ManyToOne
    private Guest guest;
}
