package org.example.hoteldemo.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter
@Setter
@NoArgsConstructor
public class Guest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private String phone;
    private Gender gender;

    private enum Gender {
        MALE, FEMALE
    }

    public Guest( String name, String phone, Gender gender) {

        this.name = name;
        this.phone = phone;
        this.gender = gender;
    }
    @OneToMany(mappedBy = "guest")
    private List<Room> rooms = new ArrayList<>();
    @OneToMany(mappedBy = "guest")
    private  List<Reservation> reservations = new ArrayList<>();


    public  void addRoom(Room room) {
        rooms.add(room);
        room.setGuest(this);
    }

    public void addReservation(Reservation reservation) {
        reservations.add(reservation);
        reservation.setGuest(this);
    }
}
