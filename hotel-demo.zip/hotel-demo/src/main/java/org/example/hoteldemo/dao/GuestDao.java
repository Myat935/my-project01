package org.example.hoteldemo.dao;

import org.example.hoteldemo.entity.Guest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.relational.core.sql.In;

public interface GuestDao extends JpaRepository<Guest, Integer> {
}
