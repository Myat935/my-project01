package org.example.hoteldemo.service;

import lombok.RequiredArgsConstructor;
import org.example.hoteldemo.dao.GuestDao;
import org.example.hoteldemo.dao.ReservationDao;
import org.example.hoteldemo.dao.RoomDao;
import org.example.hoteldemo.entity.Guest;
import org.example.hoteldemo.entity.Reservation;
import org.example.hoteldemo.entity.Room;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class GuestService {

    private final GuestDao guestDao;
    private final RoomDao roomDao;
    private final ReservationDao reservationDao;


    public String makeReservationWithNewGuest(Guest guest, int roomId, String checkInDate, String checkOutDate) {

        guestDao.save(guest);


        Room room = roomDao.findById(roomId).orElse(null);
        if (room == null) {
            return "Room not found.";
        }


        if (!roomDao.isRoomAvailable(roomId, checkInDate, checkOutDate)) {
            return "Room is not available for the selected dates.";
        }


        Reservation reservation = new Reservation();
        reservation.setGuest(guest);
        reservation.setRoom(room);
        reservation.setCheckInDate(checkInDate);
        reservation.setCheckOutDate(checkOutDate);


        reservationDao.save(reservation);

        return "Reservation successful!";
    }
}
