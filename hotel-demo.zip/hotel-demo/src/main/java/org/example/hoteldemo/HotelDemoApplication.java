package org.example.hoteldemo;

import lombok.RequiredArgsConstructor;
import org.example.hoteldemo.dao.GuestDao;
import org.example.hoteldemo.dao.ReservationDao;
import org.example.hoteldemo.dao.RoomDao;
import org.example.hoteldemo.entity.Room;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.transaction.annotation.Transactional;

@SpringBootApplication
@RequiredArgsConstructor
public class HotelDemoApplication {

    private final RoomDao roomDao;


    @Bean
    @Transactional @Profile("dev")
    public ApplicationRunner applicationRunner() {
        return args -> {

            Room room1 = new Room(120, Room.RoomType.SINGLE);
            Room room2 = new Room(200, Room.RoomType.DOUBLE);
            Room room3 = new Room(300, Room.RoomType.SUITE);
            Room room4 = new Room(400, Room.RoomType.DOUBLE);
            Room room5 = new Room(500, Room.RoomType.SINGLE);
            Room room6 = new Room(600, Room.RoomType.SUITE);
            Room room7 = new Room(700, Room.RoomType.SINGLE);
            Room room8 = new Room(800, Room.RoomType.DOUBLE);
            Room room9 = new Room(900, Room.RoomType.SUITE);
            Room room10 = new Room(1000, Room.RoomType.DOUBLE);

            // Save rooms to the database using roomDao
            roomDao.save(room1);
            roomDao.save(room2);
            roomDao.save(room3);
            roomDao.save(room4);
            roomDao.save(room5);
            roomDao.save(room6);
            roomDao.save(room7);
            roomDao.save(room8);
            roomDao.save(room9);
            roomDao.save(room10);
        };
    }

    public static void main(String[] args) {
        SpringApplication.run(HotelDemoApplication.class, args);
    }
}
