package com.jdc.calendarTest;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class CalendarApp {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java CalendarApp <year> <month>");
            return;
        }

        try {
            int year = Integer.parseInt(args[0]);
            String monthStr = args[1].toLowerCase();
            int month = getMonthNumber(monthStr);

            if (month == -1) {
                System.out.println("Invalid month name");
                return;
            }

            printCalendar(year, month);
        } catch (NumberFormatException e) {
            System.out.println("Invalid year format");
        }
    }

    private static int getMonthNumber(String month) {
        switch (month) {
            case "january":
            case "jan":
                return 0;
            case "february":
            case "feb":
                return 1;
            case "march":
            case "mar":
                return 2;
            case "april":
            case "apr":
                return 3;
            case "may":
                return 4;
            case "june":
            case "jun":
                return 5;
            case "july":
            case "jul":
                return 6;
            case "august":
            case "aug":
                return 7;
            case "september":
            case "sep":
            case "sept":
                return 8;
            case "october":
            case "oct":
                return 9;
            case "november":
            case "nov":
                return 10;
            case "december":
            case "dec":
                return 11;
            default:
                return -1;
        }
    }

    private static void printCalendar(int year, int month) {
        Calendar calendar = new GregorianCalendar(year, month, 1);
        String[] months = {
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        };

        int firstDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int daysInMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);

        System.out.printf("     %s %d\n", months[month], year);
        System.out.println("Su Mo Tu We Th Fr Sa");

        int dayOfWeekIndex = firstDayOfWeek - Calendar.SUNDAY;
        for (int i = 0; i < dayOfWeekIndex; i++) {
            System.out.print("   ");
        }

        for (int day = 1; day <= daysInMonth; day++) {
            System.out.printf("%2d ", day);
            if ((dayOfWeekIndex + day) % 7 == 0) {
                System.out.println();
            }
        }
        System.out.println();
    }
}